import React from 'react'

function HealthSolution() {
  return (
    <div className='hp-about-section' id="action2">
      <div>
        <h1>About Us</h1>
      </div>
      <div>
        <p>Sharavati Hospitals, Vijaynagar, Bengaluru, started in 1998 is a multi-specialty hospital reputed for its diverse range of medical care service.
              A patient-centric approach, coupled with years of experience and with Good Expirienced Doctors, Paramedical and
              Nursing Staffs around the clock serving the Vijaynagar locality from past 30 years</p>
      </div>
    </div>
  )
}

export default HealthSolution
