import React from 'react'

function Footer() {
  return (
    <div className='footer'>
        <h6>© 2023 Crafted By WebMechaniks.</h6>
    </div>
  )
}

export default Footer
